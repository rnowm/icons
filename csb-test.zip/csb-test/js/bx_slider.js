// JavaScript Document

$(document).ready(function(){
  $('.bxslider').bxSlider();
});